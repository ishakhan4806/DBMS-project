create database ls;
-- Use your database
USE ls;

CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL, 
    email VARCHAR(100),
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Note: image LONGBLOB for storing images directly.
CREATE TABLE IF NOT EXISTS items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    item_name VARCHAR(100) NOT NULL,
    description TEXT,
    category VARCHAR(50), -- Optional, can be NULL or removed if not needed
    location_lost VARCHAR(100),
    location_found VARCHAR(100),
    date_lost DATE,
    date_found DATE,
    status ENUM('LOST', 'FOUND', 'RETURNED') DEFAULT 'LOST',
    image LONGBLOB, -- For storing images directly
    posted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);
-- Insert an admin user (if you haven't already, or update existing)
INSERT INTO users (username, password, email, is_admin)
VALUES ('admin', 'admin123', 'admin@lostandfound.com', TRUE)
ON DUPLICATE KEY UPDATE password = 'admin123', email = 'admin@lostandfound.com', is_admin = TRUE;

